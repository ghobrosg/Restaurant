// RestaurantApp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;

int main()
{//choosing sandwich
    int sandwich;
    string SandwichName;
    int price;
    cout << "Which sandwich would you like\n";
    cout << "1. Chicken (3$) 2. Beef (4$) 3. Fish (2$) 4. Breakfast (1$) 5. Vegetarian (5$) 6. No Sandwich (0$)\n";
    cin >> sandwich;
    if (sandwich == 1) {
        SandwichName = "Chicken";
        price = 3;
    }
    else if (sandwich == 2) {
        SandwichName = "Beef";
        price = 4;
    }
    else if (sandwich == 3) {
        SandwichName = "Fish";
        price = 2;
    }
    else if (sandwich == 4) {
        SandwichName = "Breakfast";
        price = 1;
    }
    else if (sandwich == 5) {
        SandwichName = "Vegetarian";
        price = 5;
    }
    else if (sandwich == 6) {
        SandwichName = "No Sandwich";
            price = 0;
    } //choosing side
    int side;
    string sideName;
    cout << "Which side would you like\n";
    cout << "1. Fries (3$) 2. Onion Rings (4$) 3. Salad (2$) 4. No Side (0$)\n";
    cin >> side; 
    if (side == 1) {
        sideName = "Fries";
        price = price + 3;
    }
    else if (side == 2) {
        sideName = "Onion Rings";
        price = price + 4;
    }
    else if (side == 3) {
        sideName = "Salad";
        price = price + 2;
    }
    else if (side == 4) {
        sideName = "No Side";
        price = price + 0;
    } //choosing side
    int drink;
    string drinkName;
    cout << "Which drink would you like\n";
    cout << "1. Large (3$) 2. Medium (2$) 3. Small (1$) 4. No Drink (0$)\n";
    cin >> drink;
    if (drink == 1) {
        drinkName = "Large";
        price = price + 3;
    } 
    else if (drink == 2) {
        drinkName = "Medium";
        price = price + 2;
    }
    else if (drink == 3) {
        drinkName = "Small";
        price = price + 1;
    }
    else if (drink == 4) {
        drinkName = "No Drink";
        price = price + 0;
    }
    //Final reciept
    cout << "You order: \n"; 
    cout << "Sandwich: " << SandwichName << endl; 
    cout << "Side: " << sideName << endl;
    cout << "Drink: " << drinkName << endl;
    cout << "Subtotal: " << price << "$" << endl;
    cout << "Taxes: " << price * 0.13 << "$" << endl;
    cout << "Total: " << price * 1.13 << "$" << endl;
    system("pause");
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
